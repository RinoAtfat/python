# Face Generation with PyTorch 
Face Generation Project: Udacity - Deep Learning Nanodegree Program

## Introduction

This project, uses generative adversarial networks to generate new images of faces.